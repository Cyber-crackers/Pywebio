# The deployment address of the demos module
demo_host = 'http://pywebio-demos.pywebio.online'

# The deployment address of https://github.com/wang0618/pywebio-chart-gallery repo
charts_demo_host = 'http://pywebio-charts.pywebio.online'
